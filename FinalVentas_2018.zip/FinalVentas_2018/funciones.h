#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

char* dinamicCharacter(char character[]);

char cargarCaracter(int tam, char caracteres[]);

#endif // FUNCIONES_H_INCLUDED
